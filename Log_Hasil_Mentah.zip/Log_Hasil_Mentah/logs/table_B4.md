| Skenario | Train Acc (eval, tanpa aug) | Val Acc | Gap (train-val) | Val Loss | Test Acc | Test Macro-F1 | Best epoch |
|---|---|---|---|---|---|---|---|
| B4a tanpa augmentasi | 1.0000 | 0.9798 | +0.0202 | 0.0851 | 0.9663 | 0.9664 | 4 |
| B4b dengan augmentasi | 0.9978 | 0.9764 | +0.0214 | 0.1003 | 0.9663 | 0.9662 | 7 |