| Kode | Strategi | Arsitektur | Aug | Trainable params | Learning rate | Epoch konvergen (best/jalan) | Waktu latih (s) | Val Acc | Test Macro-F1 |
|---|---|---|---|---|---|---|---|---|---|
| B1 | B1 Scratch | resnet18 | ya | 11,181,642 | all=0.001 | 13/18 | 211.6 | 0.5354 | 0.5368 |
| B2 | B2 Feature Extraction | resnet18 | ya | 5,130 | fc=0.001 | 15/20 | 215.8 | 0.9764 | 0.9730 |
| B3 | B3 Fine-Tuning (layer4+fc) | resnet18 | ya | 8,398,858 | layer4=0.0001; fc=0.001 | 7/12 | 126.3 | 0.9764 | 0.9662 |
| B4 noaug | B4a tanpa augmentasi | resnet18 | tidak | 8,398,858 | layer4=0.0001; fc=0.001 | 4/9 | 64.2 | 0.9798 | 0.9664 |
| B4 aug | B4b dengan augmentasi | resnet18 | ya | 8,398,858 | layer4=0.0001; fc=0.001 | 7/12 | 128.0 | 0.9764 | 0.9662 |
| B5 efficientnet b0 | B5 efficientnet_b0 | efficientnet_b0 | tidak | 1,142,202 | features[7:9]=0.0001; classifier[1]=0.001 | 10/15 | 130.8 | 0.9933 | 0.9798 |
| B5 mobilenet v3 small | B5 mobilenet_v3_small | mobilenet_v3_small | tidak | 360,794 | features[11:13]=0.0001; classifier[3]=0.001 | 10/15 | 104.5 | 0.9764 | 0.9664 |