| Model | Trainable | Total params | Test Macro-F1 | Waktu latih (s) | Detik/epoch |
|---|---|---|---|---|---|
| resnet18 / scratch | 11,181,642 | 11,181,642 | 0.5368 | 211.6 | 11.8 |
| resnet18 / feature_extraction | 5,130 | 11,181,642 | 0.9730 | 215.8 | 10.8 |
| resnet18 / finetune | 8,398,858 | 11,181,642 | 0.9662 | 126.3 | 10.5 |
| efficientnet_b0 / finetune | 1,142,202 | 4,020,358 | 0.9798 | 130.8 | 8.7 |
| mobilenet_v3_small / finetune | 360,794 | 1,528,106 | 0.9664 | 104.5 | 7.0 |